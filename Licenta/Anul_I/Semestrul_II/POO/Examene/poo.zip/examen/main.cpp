#include <iostream>
#include "Sticker.h"
#include "Hartie.h"
int main(int argc, char *argv[])
{
    
    return 0;
}
